# NEXTSTEP Education Consultancy Website

A modern, responsive React + Next.js website for NEXTSTEP education consultancy, designed to help students pursue higher education in Europe.

## 🌟 Features

- **Modern Design**: Clean, professional design with brand colors and responsive layout
- **Comprehensive Pages**: Home, About, Services, Destinations, Testimonials, Contact
- **Interactive Elements**: WhatsApp integration, contact forms, smooth scrolling
- **SEO Optimized**: Meta tags, OpenGraph, and structured data ready
- **Mobile-First**: Fully responsive design that works on all devices
- **Fast Performance**: Built with Next.js 14 for optimal performance

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn package manager

### Installation

1. **Clone or download this repository**
```bash
git clone <your-repository-url>
cd nextstep-education
```

2. **Install dependencies**
```bash
npm install
# or
yarn install
```

3. **Add your logo** (See Logo Upload section below)

4. **Run the development server**
```bash
npm run dev
# or
yarn dev
```

5. **Open your browser**
Navigate to [http://localhost:3000](http://localhost:3000) to see the website.

## 📷 Logo Upload Instructions

The website is configured to use your NEXTSTEP logo. Here's how to add it:

### Method 1: Replace the Logo File (Recommended)

1. **Prepare your logo**:
   - Format: PNG or JPG (PNG recommended for transparent background)
   - Recommended size: 200x200 pixels minimum
   - Name your file: `logo.png`

2. **Add logo to the project**:
   - Create a `public` folder in the root directory if it doesn't exist
   - Place your `logo.png` file in the `public` folder
   - The path should be: `public/logo.png`

3. **File structure should look like**:
```
nextstep-education/
├── public/
│   ├── logo.png          ← Your logo here
│   ├── favicon.ico       ← Optional: Your favicon
│   └── ...
├── src/
├── package.json
└── ...
```

### Method 2: Use a Different File Name

If you want to use a different filename:

1. Place your logo in the `public` folder with your preferred name (e.g., `nextstep-logo.jpg`)

2. Update the logo references in these files:
   - `src/components/Header.tsx` (line ~28): Change `src="/logo.png"` to `src="/your-logo-name.jpg"`
   - `src/components/Footer.tsx` (line ~34): Change `src="/logo.png"` to `src="/your-logo-name.jpg"`
   - `src/app/layout.tsx` (lines 31 & 47): Update OpenGraph and Twitter image URLs

### Method 3: Use External URL (Not Recommended)

If you prefer to host the logo externally:

1. Upload your logo to a reliable image hosting service
2. Update the `src` attributes in the files mentioned above with your external URL
3. Ensure the URL is added to `next.config.js` in the `remotePatterns` array

## 🎨 Brand Customization

The website uses NEXTSTEP's brand colors:

- **Primary**: #0B495A (Dark teal)
- **Secondary**: #6C8A92 (Medium teal)
- **Accent**: #939B9D (Light gray)
- **Tint**: #E7F2F4 (Very light teal)

These colors are used throughout the website in:
- Buttons and CTAs
- Headers and navigation
- Cards and sections
- Gradients and backgrounds

## 📧 Contact Information Update

The website includes your contact details:

- **Email**: consultant.ns.nextstep@gmail.com
- **WhatsApp**: +371 26 321 512 and +48 516 875 116

If you need to update these, search and replace them in:
- `src/components/Header.tsx`
- `src/components/Footer.tsx`
- `src/components/WhatsAppFloat.tsx`
- All page components that include contact information

## 📱 WhatsApp Integration

The website includes multiple WhatsApp integration points:

1. **Floating WhatsApp Button**: Fixed position button on all pages
2. **CTA Buttons**: Various call-to-action buttons throughout the site
3. **Service Inquiries**: Each service has a WhatsApp inquiry link
4. **Country-specific Messages**: Destination pages have tailored WhatsApp messages

All WhatsApp links use your primary number (+371 26 321 512) with pre-filled messages relevant to the context.

## 🏗️ Build for Production

To build the website for production:

```bash
npm run build
# or
yarn build
```

To start the production server:

```bash
npm run start
# or
yarn start
```

## 📁 Project Structure

```
nextstep-education/
├── public/              # Static files (logo, favicon, etc.)
├── src/
│   ├── app/            # Next.js app directory
│   │   ├── about/      # About page
│   │   ├── contact/    # Contact page
│   │   ├── services/   # Services page
│   │   ├── layout.tsx  # Root layout
│   │   ├── page.tsx    # Home page
│   │   └── globals.css # Global styles
│   ├── components/     # React components
│   │   ├── ui/         # UI components
│   │   ├── Header.tsx  # Site header
│   │   ├── Footer.tsx  # Site footer
│   │   └── ...         # Other components
│   └── lib/
│       └── utils.ts    # Utility functions
├── next.config.js      # Next.js configuration
├── tailwind.config.js  # Tailwind CSS configuration
├── package.json        # Dependencies and scripts
└── README.md          # This file
```

## 🔧 Customization

### Adding New Pages

1. Create a new folder in `src/app/` with the page name
2. Add a `page.tsx` file in that folder
3. Update navigation in `src/components/Header.tsx`
4. Update footer links in `src/components/Footer.tsx`

### Modifying Existing Content

- **Home page content**: Edit `src/app/page.tsx`
- **About page content**: Edit `src/app/about/page.tsx`
- **Services**: Edit `src/app/services/page.tsx`
- **Contact information**: Update in multiple component files

### Styling Changes

The website uses Tailwind CSS for styling. You can:
- Modify existing classes in component files
- Add custom CSS to `src/app/globals.css`
- Update the Tailwind config in `tailwind.config.js`

## 📞 Support

If you need help with:
- Logo upload issues
- Content modifications  
- Technical setup
- Customization requests

Feel free to reach out for technical support.

## 🎯 Key Features Implemented

- ✅ Responsive design for all devices
- ✅ SEO optimized with proper meta tags
- ✅ WhatsApp integration throughout
- ✅ Contact forms with validation
- ✅ Professional service showcase
- ✅ Student testimonials section
- ✅ Multiple call-to-action points
- ✅ Brand-consistent design
- ✅ Fast loading performance
- ✅ Accessibility considerations

## 🌐 Deployment

You can deploy this website to:
- **Vercel** (recommended for Next.js)
- **Netlify**
- **AWS Amplify**
- **Any hosting provider that supports Node.js**

Make sure to:
1. Upload your logo before deployment
2. Test all contact forms and WhatsApp links
3. Verify all pages load correctly
4. Check responsive design on different devices

Your NEXTSTEP education consultancy website is now ready to help students achieve their European education dreams!