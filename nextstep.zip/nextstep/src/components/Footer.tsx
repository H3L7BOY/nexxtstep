import Link from 'next/link'
import Image from 'next/image'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const destinations = [
    { name: 'Latvia', href: '/destinations/latvia' },
    { name: 'Poland', href: '/destinations/poland' },
    { name: 'Czech Republic', href: '/destinations/czech-republic' },
    { name: 'Slovakia', href: '/destinations/slovakia' },
    { name: 'Lithuania', href: '/destinations/lithuania' },
    { name: 'Estonia', href: '/destinations/estonia' },
    { name: 'Slovenia', href: '/destinations/slovenia' },
  ]

  const services = [
    { name: 'Study Abroad Consultation', href: '/services#consultation' },
    { name: 'University Selection', href: '/services#university' },
    { name: 'Visa Guidance', href: '/services#visa' },
    { name: 'Accommodation Support', href: '/services#accommodation' },
    { name: '24×7 Support', href: '/services#support' },
  ]

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center space-x-3 mb-4">
              <Image
                src="/logo.png" // This will be your uploaded logo
                alt="NEXTSTEP Education Consultancy Logo"
                width={40}
                height={40}
                className="h-10 w-auto"
              />
              <div>
                <h2 className="text-xl font-bold">NEXTSTEP</h2>
                <p className="text-xs text-gray-400">FOR YOUR BEST STEP</p>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              Your trusted partner for European higher education. We guide students through 
              every step of their study abroad journey.
            </p>
            <div className="space-y-2 text-sm">
              <p className="text-gray-300">📧 consultant.ns.nextstep@gmail.com</p>
              <p className="text-gray-300">📱 +371 26 321 512</p>
              <p className="text-gray-300">📱 +48 516 875 116</p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><Link href="/services" className="text-gray-400 hover:text-white transition-colors">Our Services</Link></li>
              <li><Link href="/testimonials" className="text-gray-400 hover:text-white transition-colors">Success Stories</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Our Services</h3>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service.name}>
                  <Link href={service.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Destinations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Study Destinations</h3>
            <ul className="space-y-2">
              {destinations.map((destination) => (
                <li key={destination.name}>
                  <Link href={destination.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {destination.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © {currentYear} NEXTSTEP Education Consultancy. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <a
                href="https://wa.me/37126321512"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-green-500 transition-colors"
              >
                WhatsApp
              </a>
              <a
                href="mailto:consultant.ns.nextstep@gmail.com"
                className="text-gray-400 hover:text-blue-500 transition-colors"
              >
                Email
              </a>
              <Link href="/contact" className="text-gray-400 hover:text-white transition-colors">
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer