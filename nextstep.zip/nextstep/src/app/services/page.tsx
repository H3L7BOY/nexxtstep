import Header from '@/components/Header'
import Footer from '@/components/Footer'
import WhatsAppFloat from '@/components/WhatsAppFloat'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const ServicesPage = () => {
  const services = [
    {
      icon: '📚',
      title: 'Study Abroad Consultation',
      description: 'Personalized guidance to help you choose the right course and university for your career goals.',
      features: [
        'One-on-one counseling sessions',
        'Career assessment and planning',
        'Course and university matching',
        'Application strategy development',
        'Timeline planning and preparation'
      ],
      price: 'Free Initial Consultation'
    },
    {
      icon: '🏫',
      title: 'University & Course Selection',
      description: 'Expert assistance in selecting the best universities and programs based on your profile.',
      features: [
        'University rankings analysis',
        'Course curriculum comparison', 
        'Admission requirements evaluation',
        'Scholarship opportunities identification',
        'Application deadline management'
      ],
      price: 'Included in Package'
    },
    {
      icon: '📄',
      title: 'Documentation Support',
      description: 'Complete assistance with preparing and organizing all required documents.',
      features: [
        'Document checklist preparation',
        'Translation and attestation guidance',
        'Statement of purpose writing',
        'Letter of recommendation coordination',
        'Academic transcript evaluation'
      ],
      price: 'Comprehensive Service'
    },
    {
      icon: '✈️',
      title: 'Visa Guidance',
      description: 'Complete visa application support with document preparation and interview coaching.',
      features: [
        'Visa application assistance',
        'Document review and preparation',
        'Interview preparation sessions',
        'Embassy appointment booking',
        'Visa status tracking'
      ],
      price: 'Expert Support'
    },
    {
      icon: '💭',
      title: 'Counselling Services',
      description: 'Professional counseling to address concerns and prepare for studying abroad.',
      features: [
        'Pre-departure counseling',
        'Cultural adaptation guidance',
        'Academic expectations briefing',
        'Mental health support',
        'Family consultation sessions'
      ],
      price: 'Ongoing Support'
    },
    {
      icon: '💰',
      title: 'Funding Assistance',
      description: 'Help securing scholarships, loans, and other funding opportunities.',
      features: [
        'Scholarship research and applications',
        'Education loan guidance',
        'Financial planning assistance',
        'Budget planning for studies',
        'Part-time work opportunities'
      ],
      price: 'Financial Guidance'
    },
    {
      icon: '🏛️',
      title: 'Embassy Appointments',
      description: 'Assistance with booking and preparing for embassy appointments.',
      features: [
        'Appointment slot booking',
        'Document preparation checklist',
        'Mock interview sessions',
        'Embassy-specific guidance',
        'Follow-up support'
      ],
      price: 'Professional Service'
    },
    {
      icon: '🚗',
      title: 'Airport Pickup',
      description: 'Safe and reliable airport pickup service in your destination country.',
      features: [
        'Dedicated pickup service',
        'Local orientation tour',
        'Initial settling assistance',
        'Emergency contact provision',
        'University campus visit'
      ],
      price: 'Welcome Service'
    },
    {
      icon: '🏠',
      title: 'Accommodation Support',
      description: 'Help finding safe and affordable housing options near your university.',
      features: [
        'University dormitory applications',
        'Private accommodation search',
        'Lease agreement assistance',
        'Safety and location guidance',
        'Roommate matching service'
      ],
      price: 'Housing Solutions'
    },
    {
      icon: '💼',
      title: 'Part-time Job Help',
      description: 'Assistance in finding suitable part-time employment opportunities.',
      features: [
        'Job search assistance',
        'Resume/CV preparation',
        'Interview preparation',
        'Work permit guidance',
        'Employer networking'
      ],
      price: 'Career Support'
    },
    {
      icon: '📋',
      title: 'Post-arrival Documentation',
      description: 'Help with completing all necessary documentation after arrival.',
      features: [
        'Residence permit applications',
        'University enrollment completion',
        'Bank account opening',
        'Health insurance registration',
        'Local registration procedures'
      ],
      price: 'Settlement Service'
    },
    {
      icon: '🆘',
      title: '24×7 Support',
      description: 'Round-the-clock support for any emergencies or urgent queries.',
      features: [
        '24/7 helpline access',
        'Emergency assistance',
        'Academic support',
        'Personal guidance',
        'Crisis management'
      ],
      price: 'Always Available'
    }
  ]

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0B495A] to-[#6C8A92] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Our Comprehensive Services
          </h1>
          <p className="text-xl text-[#E7F2F4] max-w-3xl mx-auto">
            End-to-end support for your European education journey. From initial consultation 
            to post-graduation assistance, we're here for every step.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 border-l-4 border-[#0B495A]">
                <div className="flex items-center mb-4">
                  <div className="text-4xl mr-4">{service.icon}</div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{service.title}</h3>
                    <p className="text-sm text-[#6C8A92] font-medium">{service.price}</p>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed">{service.description}</p>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-900 text-sm">What's Included:</h4>
                  <ul className="space-y-1">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-[#0B495A] rounded-full mr-2 flex-shrink-0"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-200">
                  <Button asChild size="sm" className="w-full bg-[#0B495A] hover:bg-[#6C8A92]">
                    <a href={`https://wa.me/37126321512?text=Hi%20NEXTSTEP,%20I'm%20interested%20in%20your%20${encodeURIComponent(service.title)}%20service.%20Can%20you%20provide%20more%20details?`} target="_blank" rel="noopener noreferrer">
                      Get More Info
                    </a>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Service Packages
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose the package that best fits your needs, or let us customize a solution for you.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Basic Package',
                description: 'Essential services to get you started',
                features: [
                  'Free initial consultation',
                  'University selection guidance',
                  'Application assistance',
                  'Basic documentation support',
                  'Email support'
                ],
                cta: 'Get Started',
                popular: false
              },
              {
                name: 'Complete Package',
                description: 'Comprehensive support from start to finish',
                features: [
                  'All Basic Package services',
                  'Visa guidance and support',
                  'Interview preparation',
                  'Pre-departure briefing',
                  'Post-arrival assistance',
                  '24/7 WhatsApp support'
                ],
                cta: 'Most Popular',
                popular: true
              },
              {
                name: 'Premium Package',
                description: 'Full-service support with premium benefits',
                features: [
                  'All Complete Package services',
                  'Airport pickup service',
                  'Accommodation assistance',
                  'Part-time job guidance',
                  'First-year ongoing support',
                  'Priority support access'
                ],
                cta: 'Premium Choice',
                popular: false
              }
            ].map((pkg, index) => (
              <div key={index} className={`rounded-xl p-8 relative ${pkg.popular ? 'bg-gradient-to-br from-[#0B495A] to-[#6C8A92] text-white' : 'bg-gray-50 border border-gray-200'}`}>
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-gray-900 px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                
                <h3 className={`text-2xl font-bold mb-2 ${pkg.popular ? 'text-white' : 'text-gray-900'}`}>
                  {pkg.name}
                </h3>
                <p className={`mb-6 ${pkg.popular ? 'text-gray-200' : 'text-gray-600'}`}>
                  {pkg.description}
                </p>
                
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <div className={`w-2 h-2 rounded-full mr-3 ${pkg.popular ? 'bg-white' : 'bg-[#0B495A]'}`}></div>
                      <span className={pkg.popular ? 'text-gray-100' : 'text-gray-600'}>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button asChild className={`w-full ${pkg.popular ? 'bg-white text-[#0B495A] hover:bg-gray-100' : 'bg-[#0B495A] hover:bg-[#6C8A92] text-white'}`}>
                  <Link href="/contact">{pkg.cta}</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#0B495A] to-[#6C8A92] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-[#E7F2F4]">
            Book your free consultation today and let us create a personalized plan for your European education journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-[#0B495A] hover:bg-gray-100">
              <Link href="/contact">Book Free Consultation</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#0B495A]">
              <a href="https://wa.me/37126321512" target="_blank" rel="noopener noreferrer">
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}

export default ServicesPage