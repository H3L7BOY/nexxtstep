import Header from '@/components/Header'
import Footer from '@/components/Footer'
import WhatsAppFloat from '@/components/WhatsAppFloat'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const AboutPage = () => {
  const values = [
    {
      icon: '🎯',
      title: 'Student-First Approach',
      description: 'Every decision we make prioritizes our students\' success and well-being. Your dreams become our mission.'
    },
    {
      icon: '🤝',
      title: 'Transparency',
      description: 'We maintain complete honesty about processes, costs, and timelines. No hidden fees or false promises.'
    },
    {
      icon: '🔍',
      title: 'Personalized Guidance',
      description: 'Each student receives customized advice based on their unique background, interests, and career goals.'
    },
    {
      icon: '📞',
      title: 'Continuous Support',
      description: 'Our relationship doesn\'t end with admission. We provide ongoing support throughout your academic journey.'
    }
  ]

  const team = [
    {
      name: 'Expert Education Consultants',
      role: 'University Partnerships & Admissions',
      description: 'Our team has direct relationships with 50+ European universities and understands their specific requirements.'
    },
    {
      name: 'Visa Specialists',
      role: 'Immigration & Documentation',
      description: 'Certified visa consultants with expertise in European student visa processes and embassy requirements.'
    },
    {
      name: 'Student Success Managers',
      role: 'Post-Arrival Support',
      description: 'Dedicated support staff who ensure smooth transition and continued success after arrival in Europe.'
    }
  ]

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0B495A] to-[#6C8A92] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About NEXTSTEP
            </h1>
            <p className="text-xl text-[#E7F2F4] max-w-3xl mx-auto leading-relaxed">
              Your trusted partner for European higher education, dedicated to making 
              study abroad dreams accessible, affordable, and achievable.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">Our Mission</h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                At NEXTSTEP, our mission is to bridge the gap between ambitious students and world-class 
                European education opportunities. We believe that quality higher education should be 
                accessible to every deserving student, regardless of their background.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed mb-8">
                We are committed to providing comprehensive, transparent, and personalized guidance 
                that transforms the complex study abroad process into a smooth, successful journey.
              </p>
              <div className="bg-[#E7F2F4] p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#0B495A] mb-3">Why Europe?</h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3"></div>
                    World-renowned universities with high global rankings
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3"></div>
                    Affordable tuition fees compared to US/UK
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3"></div>
                    Rich cultural diversity and historical heritage
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3"></div>
                    Strong job market and career opportunities
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3"></div>
                    High quality of life and safety standards
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">Our Vision</h2>
              <div className="bg-gradient-to-br from-[#0B495A] to-[#6C8A92] text-white p-8 rounded-xl">
                <p className="text-lg leading-relaxed mb-6">
                  To become the most trusted and comprehensive education consultancy for European 
                  higher education, known for our integrity, expertise, and unwavering commitment 
                  to student success.
                </p>
                <p className="text-lg leading-relaxed mb-6">
                  We envision a world where geographical boundaries don't limit educational 
                  aspirations, and where every student can access the opportunities they deserve.
                </p>
                <div className="bg-white/10 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Our Promise</h4>
                  <p className="text-sm">
                    "We don't just help you get admitted; we ensure you thrive in your new academic 
                    and cultural environment."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These principles guide every interaction, decision, and service we provide to our students.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 text-center">
                <div className="text-4xl mb-4">{value.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Expert Team
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A dedicated team of professionals with extensive experience in European education 
              and student success.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {team.map((member, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-[#0B495A] to-[#6C8A92] rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                  {member.name.split(' ').map(word => word[0]).join('').substring(0, 2)}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-[#6C8A92] font-medium mb-3">{member.role}</p>
                <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
              </div>
            ))}
          </div>

          <div className="bg-[#E7F2F4] rounded-xl p-8 text-center">
            <h3 className="text-2xl font-bold text-[#0B495A] mb-4">
              Combined Experience
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div>
                <div className="text-3xl font-bold text-[#0B495A]">15+</div>
                <div className="text-gray-600">Years Experience</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#0B495A]">2000+</div>
                <div className="text-gray-600">Students Guided</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#0B495A]">50+</div>
                <div className="text-gray-600">University Partners</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#0B495A]">100%</div>
                <div className="text-gray-600">Success Rate</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Student Journey Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Your Journey With NEXTSTEP
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From initial consultation to graduation, we're with you every step of the way.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Free Consultation',
                description: 'Understand your goals, assess your profile, and identify the best opportunities.'
              },
              {
                step: '02', 
                title: 'Application Process',
                description: 'Complete application support including documents, essays, and university submissions.'
              },
              {
                step: '03',
                title: 'Visa & Preparation',
                description: 'Visa application assistance, pre-departure briefing, and arrival preparation.'
              },
              {
                step: '04',
                title: 'Ongoing Support',
                description: 'Continuous support throughout your studies, including accommodation and job assistance.'
              }
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="w-12 h-12 bg-[#0B495A] text-white rounded-lg flex items-center justify-center font-bold text-lg mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.description}</p>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-[#6C8A92]"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#0B495A] to-[#6C8A92] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Take Your Next Step?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-[#E7F2F4]">
            Join thousands of successful students who have achieved their European education dreams with NEXTSTEP.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-[#0B495A] hover:bg-gray-100">
              <Link href="/contact">Book Free Consultation</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#0B495A]">
              <a href="https://wa.me/37126321512" target="_blank" rel="noopener noreferrer">
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}

export default AboutPage