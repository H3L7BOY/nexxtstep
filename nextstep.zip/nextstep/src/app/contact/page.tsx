"use client"

import { useState } from 'react'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import WhatsAppFloat from '@/components/WhatsAppFloat'
import { Button } from '@/components/ui/button'

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    whatsapp: '',
    country: '',
    message: ''
  })
  
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setSubmitMessage('Thank you for your inquiry! We will contact you within 24 hours.')
      setFormData({
        name: '',
        email: '',
        whatsapp: '',
        country: '',
        message: ''
      })
      
      // Clear success message after 5 seconds
      setTimeout(() => setSubmitMessage(''), 5000)
    }, 1000)
  }

  const countries = [
    'Latvia',
    'Poland', 
    'Czech Republic',
    'Slovakia',
    'Lithuania',
    'Estonia',
    'Slovenia',
    'Not sure yet'
  ]

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0B495A] to-[#6C8A92] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Contact NEXTSTEP
          </h1>
          <p className="text-xl text-[#E7F2F4] max-w-2xl mx-auto">
            Ready to start your European education journey? Get in touch with our expert consultants today.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Get In Touch</h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-[#0B495A] rounded-lg flex items-center justify-center text-white text-xl flex-shrink-0">
                    📧
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-gray-900">Email Us</h3>
                    <p className="text-gray-600">Get detailed information about our services</p>
                    <a 
                      href="mailto:consultant.ns.nextstep@gmail.com"
                      className="text-[#0B495A] hover:text-[#6C8A92] font-medium"
                    >
                      consultant.ns.nextstep@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center text-white text-xl flex-shrink-0">
                    📱
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-gray-900">WhatsApp</h3>
                    <p className="text-gray-600">Chat with us instantly for quick questions</p>
                    <div className="space-y-1">
                      <a 
                        href="https://wa.me/37126321512"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-green-600 hover:text-green-700 font-medium"
                      >
                        +371 26 321 512
                      </a>
                      <a 
                        href="https://wa.me/48516875116"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-green-600 hover:text-green-700 font-medium"
                      >
                        +48 516 875 116
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-12 h-12 bg-[#6C8A92] rounded-lg flex items-center justify-center text-white text-xl flex-shrink-0">
                    🕒
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-gray-900">Business Hours</h3>
                    <p className="text-gray-600">Monday - Friday: 9:00 AM - 7:00 PM</p>
                    <p className="text-gray-600">Saturday: 10:00 AM - 4:00 PM</p>
                    <p className="text-gray-600">Sunday: Closed</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-12 h-12 bg-[#939B9D] rounded-lg flex items-center justify-center text-white text-xl flex-shrink-0">
                    🌍
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-gray-900">Study Destinations</h3>
                    <p className="text-gray-600">We specialize in 7+ European countries</p>
                    <p className="text-[#0B495A] font-medium">Latvia, Poland, Czech Republic, Slovakia, Lithuania, Estonia, Slovenia</p>
                  </div>
                </div>
              </div>

              {/* Quick Action Buttons */}
              <div className="mt-8 space-y-4">
                <Button asChild className="w-full bg-green-500 hover:bg-green-600 text-white">
                  <a href="https://wa.me/37126321512?text=Hi%20NEXTSTEP,%20I%20want%20to%20book%20a%20free%20consultation%20for%20studying%20in%20Europe." target="_blank" rel="noopener noreferrer">
                    📱 WhatsApp Consultation
                  </a>
                </Button>
                <Button asChild variant="outline" className="w-full border-[#0B495A] text-[#0B495A] hover:bg-[#0B495A] hover:text-white">
                  <a href="mailto:consultant.ns.nextstep@gmail.com?subject=Free%20Consultation%20Request&body=Hi%20NEXTSTEP,%0A%0AI%20am%20interested%20in%20studying%20in%20Europe%20and%20would%20like%20to%20book%20a%20free%20consultation.%0A%0APlease%20contact%20me%20at%20your%20earliest%20convenience.%0A%0AThank%20you!">
                    📧 Email Consultation
                  </a>
                </Button>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
                
                {submitMessage && (
                  <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg">
                    {submitMessage}
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0B495A] focus:border-transparent transition-colors"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0B495A] focus:border-transparent transition-colors"
                      placeholder="Enter your email address"
                    />
                  </div>

                  <div>
                    <label htmlFor="whatsapp" className="block text-sm font-medium text-gray-700 mb-2">
                      WhatsApp Number *
                    </label>
                    <input
                      type="tel"
                      id="whatsapp"
                      name="whatsapp"
                      required
                      value={formData.whatsapp}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0B495A] focus:border-transparent transition-colors"
                      placeholder="Enter your WhatsApp number with country code"
                    />
                  </div>

                  <div>
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-2">
                      Country of Interest *
                    </label>
                    <select
                      id="country"
                      name="country"
                      required
                      value={formData.country}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0B495A] focus:border-transparent transition-colors"
                    >
                      <option value="">Select a country</option>
                      {countries.map((country) => (
                        <option key={country} value={country}>{country}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0B495A] focus:border-transparent transition-colors resize-none"
                      placeholder="Tell us about your educational background, preferred courses, and any specific questions you have..."
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#0B495A] hover:bg-[#6C8A92] text-white py-3 text-lg"
                  >
                    {isSubmitting ? 'Sending...' : 'Send Message'}
                  </Button>
                </form>

                <p className="mt-4 text-sm text-gray-600 text-center">
                  We typically respond within 2-4 hours during business hours
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Frequently Asked Questions</h2>
          <div className="space-y-8">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">How much do your consultation services cost?</h3>
              <p className="text-gray-600">Our initial consultation is completely FREE! We believe in providing value first. After understanding your needs, we'll discuss our service packages that are designed to be affordable and comprehensive.</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">What documents do I need to prepare?</h3>
              <p className="text-gray-600">Document requirements vary by country and program. Generally, you'll need academic transcripts, English proficiency test scores, passport, statement of purpose, and letters of recommendation. We'll provide you with a complete checklist during consultation.</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">How long does the application process take?</h3>
              <p className="text-gray-600">The timeline varies from 4-8 months depending on the country and program. We recommend starting the process at least 10-12 months before your intended start date to ensure adequate preparation time.</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Do you guarantee admission?</h3>
              <p className="text-gray-600">While we cannot guarantee admission (as universities make the final decision), we have a 100% success rate with our comprehensive approach. We carefully assess your profile and only recommend programs where you have a strong chance of acceptance.</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}

export default ContactPage