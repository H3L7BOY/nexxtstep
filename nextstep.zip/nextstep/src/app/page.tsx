import Header from '@/components/Header'
import Footer from '@/components/Footer'
import WhatsAppFloat from '@/components/WhatsAppFloat'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const HomePage = () => {
  const stats = [
    { number: '2000+', label: 'Students Placed' },
    { number: '50+', label: 'Partner Universities' },
    { number: '7', label: 'European Countries' },
    { number: '24/7', label: 'Support Available' },
  ]

  const whyChooseUs = [
    {
      icon: '🎓',
      title: 'Expert Guidance',
      description: 'Our experienced consultants have in-depth knowledge of European education systems and admission processes.',
    },
    {
      icon: '🏆',
      title: '100% Success Rate',
      description: 'We take pride in our track record of successful student placements in top European universities.',
    },
    {
      icon: '💼',
      title: 'End-to-End Support',
      description: 'From university selection to post-arrival support, we handle every aspect of your study abroad journey.',
    },
    {
      icon: '🌍',
      title: 'Multiple Destinations',
      description: 'Choose from 7+ European countries with diverse programs and opportunities for international students.',
    },
  ]

  const featuredServices = [
    {
      icon: '📚',
      title: 'Study Abroad Consultation',
      description: 'Personalized guidance to help you choose the right course and university for your career goals.',
      features: [
        'One-on-one counseling sessions',
        'Career assessment and planning',
        'Course and university matching',
        'Application strategy development'
      ],
      isPopular: true
    },
    {
      icon: '📄',
      title: 'Visa Guidance',
      description: 'Complete visa application support with document preparation and interview coaching.',
      features: [
        'Visa application assistance',
        'Document review and preparation',
        'Interview preparation sessions',
        'Embassy appointment booking'
      ]
    },
    {
      icon: '🏠',
      title: 'Accommodation Support',
      description: 'Help finding safe and affordable housing options near your university.',
      features: [
        'University dormitory applications',
        'Private accommodation search',
        'Lease agreement assistance',
        'Safety and location guidance'
      ]
    }
  ]

  const testimonials = [
    {
      name: 'Priya Sharma',
      course: 'Master in Computer Science',
      university: 'University of Latvia',
      country: 'Latvia',
      testimonial: 'NEXTSTEP made my dream of studying in Europe a reality. Their guidance through every step was invaluable.',
      rating: 5
    },
    {
      name: 'Rahul Patel',
      course: 'MBA in International Business',
      university: 'Warsaw School of Economics',
      country: 'Poland',
      testimonial: 'The team at NEXTSTEP is incredibly professional and supportive. They helped me secure admission and visa without any hassle.',
      rating: 5
    },
    {
      name: 'Anita Gupta',
      course: 'Master in Marketing',
      university: 'Prague University of Economics',
      country: 'Czech Republic',
      testimonial: 'From application to arrival, NEXTSTEP was with me every step. Now I\'m successfully pursuing my masters in Prague!',
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#0B495A] via-[#6C8A92] to-slate-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Your Best Step Towards
              <span className="block text-[#E7F2F4]">European Education</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed text-[#E7F2F4]">
              Expert guidance for studying in Europe. From university selection to post-arrival support, 
              we make your study abroad dreams come true.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-[#0B495A] hover:bg-gray-100 text-lg px-8 py-6">
                <Link href="/contact">Book Free Consultation</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#0B495A] text-lg px-8 py-6">
                <a href="https://wa.me/37126321512" target="_blank" rel="noopener noreferrer">
                  Chat on WhatsApp
                </a>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -bottom-1 left-0 right-0 h-20 bg-white transform skew-y-1"></div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-[#0B495A] mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 text-sm md:text-base">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose NEXTSTEP Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose NEXTSTEP?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're committed to making your European education journey smooth, successful, and stress-free.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 text-center">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Featured Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive support services designed to ensure your success in European higher education.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            {featuredServices.map((service, index) => (
              <div key={index} className="bg-white border-2 border-gray-200 rounded-xl p-6 hover:border-[#0B495A] transition-all duration-300 relative">
                {service.isPopular && (
                  <div className="absolute -top-3 left-6 bg-[#0B495A] text-white px-3 py-1 text-sm rounded-full">
                    Most Popular
                  </div>
                )}
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-[#0B495A] rounded-full mr-3 flex-shrink-0"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <Button asChild size="lg" className="bg-[#0B495A] hover:bg-[#6C8A92] text-white">
              <Link href="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Student Success Stories
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hear from our successful students who are now thriving in European universities.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 border border-gray-200">
                <div className="flex items-center mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#0B495A] to-[#6C8A92] rounded-full flex items-center justify-center text-white text-xl font-bold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <h3 className="font-semibold text-gray-900">{testimonial.name}</h3>
                    <p className="text-sm text-[#6C8A92]">{testimonial.course}</p>
                    <p className="text-xs text-gray-500">{testimonial.university}, {testimonial.country}</p>
                  </div>
                </div>
                
                <div className="flex items-center mb-3">
                  <div className="flex">
                    {Array.from({ length: 5 }, (_, starIndex) => (
                      <svg
                        key={starIndex}
                        className={`w-5 h-5 ${starIndex < testimonial.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">({testimonial.rating}/5)</span>
                </div>
                
                <blockquote className="text-gray-700 italic leading-relaxed">
                  "{testimonial.testimonial}"
                </blockquote>
                
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-500">
                    Successfully studying in {testimonial.country} with NEXTSTEP's guidance
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <Button asChild size="lg" variant="outline" className="border-[#0B495A] text-[#0B495A] hover:bg-[#0B495A] hover:text-white">
              <Link href="/testimonials">Read More Stories</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#0B495A] to-[#6C8A92] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your European Education Journey?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-[#E7F2F4]">
            Get expert guidance from our experienced consultants. Book your free consultation today 
            and take the first step towards your dream university.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-[#0B495A] hover:bg-gray-100">
              <Link href="/contact">Book Free Consultation</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#0B495A]">
              <a href="https://wa.me/37126321512" target="_blank" rel="noopener noreferrer">
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}

export default HomePage